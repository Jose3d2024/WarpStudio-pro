
import React, { useRef, useEffect, forwardRef, useImperativeHandle, useState, useCallback } from 'react';
import { ToolMode, SymmetryMode, Point, MeshNode } from '../types';

interface MeshCanvasProps {
  image: HTMLImageElement;
  gridSize: number;
  showMesh: boolean;
  mode: ToolMode;
  symmetry: SymmetryMode;
}

const MeshCanvas = forwardRef<any, MeshCanvasProps>(({ image, gridSize, showMesh, mode, symmetry }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const nodesRef = useRef<MeshNode[]>([]);
  const zoomRef = useRef(1);
  const offsetRef = useRef<Point>({ x: 0, y: 0 });
  const selectedIdsRef = useRef<Set<string>>(new Set());
  const viewSizeRef = useRef({ width: 0, height: 0 });
  
  const [uiState, setUiState] = useState({
    selectedCount: 0,
    zoom: 1,
    historyStep: 0,
    historyTotal: 0
  });

  const historyRef = useRef<MeshNode[][]>([]);
  const historyIndexRef = useRef(-1);

  const interactionRef = useRef({
    isDragging: false,
    dragNodeId: null as string | null,
    isPanning: false,
    lastMouse: { x: 0, y: 0 },
    hasMoved: false
  });

  // Radio de influencia para la deformación suave
  const INFLUENCE_RADIUS = 180;

  const initMesh = useCallback(() => {
    if (!image || !containerRef.current) return;
    
    const container = containerRef.current;
    const padding = 80;
    const maxWidth = container.clientWidth - padding;
    const maxHeight = container.clientHeight - padding;
    
    let w = image.width;
    let h = image.height;
    const ratio = w / h;
    
    if (w > maxWidth) { w = maxWidth; h = w / ratio; }
    if (h > maxHeight) { h = maxHeight; w = h * ratio; }
    
    viewSizeRef.current = { width: w, height: h };
    zoomRef.current = 1;
    offsetRef.current = { x: 0, y: 0 };
    
    const newNodes: MeshNode[] = [];
    for (let j = 0; j <= gridSize; j++) {
      for (let i = 0; i <= gridSize; i++) {
        newNodes.push({
          x: (i / gridSize) * w,
          y: (j / gridSize) * h,
          originalX: (i / gridSize) * image.width,
          originalY: (j / gridSize) * image.height,
          id: `${i}-${j}`
        });
      }
    }
    
    nodesRef.current = newNodes;
    selectedIdsRef.current = new Set();
    
    const snapshot = JSON.parse(JSON.stringify(newNodes));
    historyRef.current = [snapshot];
    historyIndexRef.current = 0;
    
    setUiState({ 
      selectedCount: 0, 
      zoom: 1, 
      historyStep: 0, 
      historyTotal: 1 
    });
  }, [image, gridSize]);

  useEffect(() => { initMesh(); }, [initMesh]);

  /**
   * Dibuja un triángulo texturizado con alta precisión.
   * Utiliza una matriz afín para mapear coordenadas de la imagen a la malla deformada.
   */
  const drawPreciseTriangle = (
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    p0: Point, p1: Point, p2: Point,
    u0: Point, u1: Point, u2: Point
  ) => {
    // Calculamos el determinante del triángulo de origen (imagen base)
    const det = (u0.x - u2.x) * (u1.y - u2.y) - (u1.x - u2.x) * (u0.y - u2.y);
    if (Math.abs(det) < 0.01) return; // Evitar triángulos degenerados

    ctx.save();
    
    // TRUCO PARA EVITAR GRIETAS: Expandimos el recorte 0.5px hacia afuera
    // Esto oculta las rendijas causadas por el antialiasing del clip()
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.lineTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.closePath();
    ctx.clip();
    
    // Cálculo de los coeficientes de la matriz de transformación afín (Source -> Dest)
    const a = ((p0.x - p2.x) * (u1.y - u2.y) - (p1.x - p2.x) * (u0.y - u2.y)) / det;
    const b = ((p1.x - p2.x) * (u0.x - u2.x) - (p0.x - p2.x) * (u1.x - u2.x)) / det;
    const c = p2.x - a * u2.x - b * u2.y;
    const d = ((p0.y - p2.y) * (u1.y - u2.y) - (p1.y - p2.y) * (u0.y - u2.y)) / det;
    const e = ((p1.y - p2.y) * (u0.x - u2.x) - (p0.y - p2.y) * (u1.x - u2.x)) / det;
    const f = p2.y - d * u2.x - e * u2.y;
    
    // Aplicamos la matriz al contexto (es acumulativa respecto a la cámara)
    ctx.transform(a, d, b, e, c, f);
    
    // Dibujamos la imagen completa; el clipping se encarga de mostrar solo el triángulo
    ctx.drawImage(img, 0, 0);
    
    ctx.restore();
  };

  const renderLoop = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !image || nodesRef.current.length === 0) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    // Ajustar resolución del canvas si ha cambiado el tamaño del contenedor
    const parent = containerRef.current!;
    if (canvas.width !== parent.clientWidth || canvas.height !== parent.clientHeight) {
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
    }

    const z = zoomRef.current;
    const off = offsetRef.current;
    const nodes = nodesRef.current;
    const vSize = viewSizeRef.current;
    const stride = gridSize + 1;

    // Configuración de renderizado de alta fidelidad
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.fillStyle = '#080808';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 1. Transformación de CÁMARA (Navegación)
    ctx.translate(canvas.width / 2 + off.x, canvas.height / 2 + off.y);
    ctx.scale(z, z);
    ctx.translate(-vSize.width / 2, -vSize.height / 2);

    // 2. Renderizado de IMAGEN (Malla Deformada)
    if (nodes.length === stride * stride) {
      for (let j = 0; j < gridSize; j++) {
        for (let i = 0; i < gridSize; i++) {
          const n00 = nodes[j * stride + i];
          const n10 = nodes[j * stride + (i + 1)];
          const n11 = nodes[(j + 1) * stride + (i + 1)];
          const n01 = nodes[(j + 1) * stride + i];

          // Triángulo 1 (Superior Izquierdo)
          drawPreciseTriangle(ctx, image, 
            n00, n10, n01, 
            {x: n00.originalX, y: n00.originalY}, 
            {x: n10.originalX, y: n10.originalY}, 
            {x: n01.originalX, y: n01.originalY}
          );
          // Triángulo 2 (Inferior Derecho)
          drawPreciseTriangle(ctx, image, 
            n10, n11, n01, 
            {x: n10.originalX, y: n10.originalY}, 
            {x: n11.originalX, y: n11.originalY}, 
            {x: n01.originalX, y: n01.originalY}
          );
        }
      }
    }

    // 3. Renderizado de UI (Malla y Puntos de Control)
    if (showMesh) {
      ctx.beginPath();
      // Líneas horizontales
      for (let j = 0; j <= gridSize; j++) {
        const row = j * stride;
        ctx.moveTo(nodes[row].x, nodes[row].y);
        for (let i = 1; i <= gridSize; i++) ctx.lineTo(nodes[row + i].x, nodes[row + i].y);
      }
      // Líneas verticales
      for (let i = 0; i <= gridSize; i++) {
        ctx.moveTo(nodes[i].x, nodes[i].y);
        for (let j = 1; j <= gridSize; j++) ctx.lineTo(nodes[j * stride + i].x, nodes[j * stride + i].y);
      }
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = 1 / z;
      ctx.stroke();

      // Dibujar nodos
      nodes.forEach(node => {
        const isSel = selectedIdsRef.current.has(node.id);
        const [ni, nj] = node.id.split('-').map(Number);
        const isBoundary = ni === 0 || ni === gridSize || nj === 0 || nj === gridSize;
        
        ctx.beginPath();
        // Círculo exterior (glow si está seleccionado)
        if (isSel) {
          ctx.arc(node.x, node.y, 6 / z, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(34, 211, 238, 0.3)';
          ctx.fill();
        }
        
        ctx.beginPath();
        ctx.arc(node.x, node.y, (isSel ? 4 : 2.5) / z, 0, Math.PI * 2);
        ctx.fillStyle = isSel ? '#22d3ee' : isBoundary ? '#ffffff' : '#4f46e5';
        ctx.fill();
        
        if (isSel || isBoundary) {
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 0.5 / z;
          ctx.stroke();
        }
      });
    }
  }, [image, gridSize, showMesh]);

  useEffect(() => {
    let animId: number;
    const loop = () => { renderLoop(); animId = requestAnimationFrame(loop); };
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [renderLoop]);

  const screenToWorld = (sx: number, sy: number): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    return {
      x: (sx - canvas.width / 2 - offsetRef.current.x) / zoomRef.current + viewSizeRef.current.width / 2,
      y: (sy - canvas.height / 2 - offsetRef.current.y) / zoomRef.current + viewSizeRef.current.height / 2
    };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
    const world = screenToWorld(sx, sy);

    if (mode === 'MOVE') {
      interactionRef.current = { ...interactionRef.current, isPanning: true, lastMouse: { x: sx, y: sy } };
      return;
    }

    // Buscar el nodo más cercano al click
    let closest: MeshNode | null = null;
    let minDist = 24 / zoomRef.current;
    
    nodesRef.current.forEach(n => {
      const d = Math.sqrt((n.x - world.x)**2 + (n.y - world.y)**2);
      if (d < minDist) { minDist = d; closest = n; }
    });

    if (closest) {
      if (!e.shiftKey && !selectedIdsRef.current.has(closest.id)) {
        selectedIdsRef.current = new Set([closest.id]);
      } else if (e.shiftKey) {
        if (selectedIdsRef.current.has(closest.id)) selectedIdsRef.current.delete(closest.id);
        else selectedIdsRef.current.add(closest.id);
      }
      setUiState(s => ({ ...s, selectedCount: selectedIdsRef.current.size }));
      interactionRef.current = { 
        isDragging: true, 
        dragNodeId: closest.id, 
        isPanning: false, 
        lastMouse: world,
        hasMoved: false 
      };
    } else {
      if (!e.shiftKey) {
        selectedIdsRef.current = new Set();
        setUiState(s => ({ ...s, selectedCount: 0 }));
      }
      interactionRef.current = { ...interactionRef.current, isDragging: false, dragNodeId: null };
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
    const inter = interactionRef.current;

    if (inter.isPanning) {
      offsetRef.current.x += sx - inter.lastMouse.x;
      offsetRef.current.y += sy - inter.lastMouse.y;
      inter.lastMouse = { x: sx, y: sy };
      return;
    }

    if (!inter.isDragging) return;

    const world = screenToWorld(sx, sy);
    const dx = world.x - inter.lastMouse.x;
    const dy = world.y - inter.lastMouse.y;
    
    // Evitar cálculos innecesarios si el movimiento es sub-píxel
    if (Math.abs(dx) < 0.0001 && Math.abs(dy) < 0.0001) return;

    inter.hasMoved = true;
    inter.lastMouse = world;

    const nodes = nodesRef.current;
    const affectedIds = Array.from(selectedIdsRef.current);

    nodesRef.current = nodes.map(node => {
      const isDirect = selectedIdsRef.current.has(node.id);
      const [ni, nj] = node.id.split('-').map(Number);
      const isBoundary = ni === 0 || ni === gridSize || nj === 0 || nj === gridSize;

      // Nodos seleccionados se mueven al 100%
      if (isDirect) return { ...node, x: node.x + dx, y: node.y + dy };

      // Simetría
      if (symmetry !== 'NONE') {
        for (const mid of affectedIds) {
          const [mi, mj] = mid.split('-').map(Number);
          const symIds: string[] = [];
          if (symmetry === 'HORIZONTAL' || symmetry === 'BOTH') symIds.push(`${gridSize - mi}-${mj}`);
          if (symmetry === 'VERTICAL' || symmetry === 'BOTH') symIds.push(`${mi}-${gridSize - mj}`);
          if (symmetry === 'BOTH') symIds.push(`${gridSize - mi}-${gridSize - mj}`);
          
          if (symIds.includes(node.id)) {
            const mx = (ni !== mi && (symmetry === 'HORIZONTAL' || symmetry === 'BOTH')) ? -1 : 1;
            const my = (nj !== mj && (symmetry === 'VERTICAL' || symmetry === 'BOTH')) ? -1 : 1;
            return { ...node, x: node.x + dx * mx, y: node.y + dy * my };
          }
        }
      }

      // PROPAGACIÓN SUAVE (Elasticidad de la imagen)
      // Usamos una caída exponencial para que la deformación sea natural y no forme picos.
      if (!isBoundary) {
        let maxWeight = 0, fdx = 0, fdy = 0;
        for (const mid of affectedIds) {
          const m = nodes.find(n => n.id === mid);
          if (!m) continue;
          const d = Math.sqrt((node.x - m.x)**2 + (node.y - m.y)**2);
          if (d < INFLUENCE_RADIUS) {
            // Curva exponencial suavizada (Smoothstep / Gaussian-like)
            const weight = Math.pow(Math.cos((d / INFLUENCE_RADIUS) * (Math.PI / 2)), 2);
            if (weight > maxWeight) { 
              maxWeight = weight; 
              fdx = dx * weight; 
              fdy = dy * weight; 
            }
          }
        }
        if (maxWeight > 0) return { ...node, x: node.x + fdx, y: node.y + fdy };
      }

      return node;
    });
  };

  const handleMouseUp = () => {
    if (interactionRef.current.hasMoved) {
      const snapshot = JSON.parse(JSON.stringify(nodesRef.current));
      historyRef.current = historyRef.current.slice(0, historyIndexRef.current + 1);
      historyRef.current.push(snapshot);
      historyIndexRef.current++;
      setUiState(s => ({ ...s, historyStep: historyIndexRef.current, historyTotal: historyRef.current.length }));
    }
    interactionRef.current = { ...interactionRef.current, isDragging: false, dragNodeId: null, isPanning: false, hasMoved: false };
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 0.9 : 1.1;
    const newZoom = Math.max(0.1, Math.min(10, zoomRef.current * factor));
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) {
      const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
      const wBefore = screenToWorld(sx, sy);
      zoomRef.current = newZoom;
      const wAfter = screenToWorld(sx, sy);
      offsetRef.current.x += (wAfter.x - wBefore.x) * newZoom;
      offsetRef.current.y += (wAfter.y - wBefore.y) * newZoom;
      setUiState(s => ({ ...s, zoom: newZoom }));
    }
  };

  useImperativeHandle(ref, () => ({
    resetMesh: () => initMesh(),
    exportImage: () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const link = document.createElement('a');
      link.download = `warp-export-${Date.now()}.png`;
      link.href = canvas.toDataURL('image/png', 1.0);
      link.click();
    },
    clearSelection: () => {
      selectedIdsRef.current = new Set();
      setUiState(s => ({ ...s, selectedCount: 0 }));
    },
    undo: () => {
      if (historyIndexRef.current > 0) {
        historyIndexRef.current--;
        nodesRef.current = JSON.parse(JSON.stringify(historyRef.current[historyIndexRef.current]));
        setUiState(s => ({ ...s, historyStep: historyIndexRef.current }));
      }
    },
    redo: () => {
      if (historyIndexRef.current < historyRef.current.length - 1) {
        historyIndexRef.current++;
        nodesRef.current = JSON.parse(JSON.stringify(historyRef.current[historyIndexRef.current]));
        setUiState(s => ({ ...s, historyStep: historyIndexRef.current }));
      }
    },
    zoomIn: () => { zoomRef.current = Math.min(zoomRef.current * 1.25, 10); setUiState(s => ({ ...s, zoom: zoomRef.current })); },
    zoomOut: () => { zoomRef.current = Math.max(zoomRef.current * 0.8, 0.1); setUiState(s => ({ ...s, zoom: zoomRef.current })); },
    resetZoom: () => { zoomRef.current = 1; offsetRef.current = {x:0, y:0}; setUiState(s => ({ ...s, zoom: 1 })); }
  }));

  return (
    <div ref={containerRef} className="relative w-full h-full flex items-center justify-center bg-[#080808] overflow-hidden" onWheel={handleWheel}>
      <canvas 
        ref={canvasRef} 
        onMouseDown={handleMouseDown} 
        onMouseMove={handleMouseMove} 
        onMouseUp={handleMouseUp} 
        onMouseLeave={handleMouseUp}
        className={`block drop-shadow-[0_20px_50px_rgba(0,0,0,0.7)] ${mode === 'MOVE' ? 'cursor-grab' : 'cursor-crosshair'} transition-opacity duration-500 ${image ? 'opacity-100' : 'opacity-0'}`}
      />
      {image && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4 px-6 py-3 bg-[#111111]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-[0_0_80px_rgba(0,0,0,0.5)] items-center pointer-events-none z-50">
          <Badge label="Selection" value={uiState.selectedCount} color="bg-cyan-400" />
          <div className="w-px h-4 bg-white/10" />
          <Badge label="Fidelity" value={`${Math.round(uiState.zoom * 100)}%`} color="bg-indigo-400" />
          <div className="w-px h-4 bg-white/10" />
          <Badge label="Timeline" value={`${uiState.historyStep + 1}/${uiState.historyTotal}`} color="bg-amber-400" />
        </div>
      )}
    </div>
  );
});

const Badge = ({ label, value, color }: { label: string, value: string | number, color: string }) => (
  <div className="flex items-center gap-2">
    <div className={`w-2 h-2 rounded-full ${color} shadow-[0_0_10px] shadow-${color.split('-')[1]}-500`} />
    <span className="text-[10px] uppercase tracking-widest font-black text-gray-500">{label}</span>
    <span className="text-sm font-mono font-bold text-gray-100">{value}</span>
  </div>
);

export default MeshCanvas;
