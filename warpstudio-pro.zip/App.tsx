import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Move, 
  Grid3X3, 
  RotateCcw, 
  Download, 
  Zap,
  ChevronRight,
  Info,
  MousePointer2,
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  Maximize
} from 'lucide-react';
import MeshCanvas from './components/MeshCanvas';

type ToolMode = 'WARP' | 'MOVE';
type SymmetryMode = 'NONE' | 'HORIZONTAL' | 'VERTICAL' | 'BOTH';

interface AIAnalysis {
  description: string;
  suggestedWarps: Array<{
    area: string;
    action: string;
  }>;
}

const App: React.FC = () => {
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [mode, setMode] = useState<ToolMode>('WARP');
  const [showMesh, setShowMesh] = useState(true);
  const [gridSize, setGridSize] = useState(12);
  const [symmetry, setSymmetry] = useState<SymmetryMode>('NONE');
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const canvasRef = useRef<{ 
    resetMesh: () => void; 
    exportImage: () => void; 
    clearSelection: () => void;
    undo: () => void;
    redo: () => void;
    zoomIn: () => void;
    zoomOut: () => void;
    resetZoom: () => void;
  }>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          setImage(img);
          setAiAnalysis(null);
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAiAnalyze = async () => {
    if (!image) return;
    setIsAnalyzing(true);
    
    try {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = image.width;
      tempCanvas.height = image.height;
      const ctx = tempCanvas.getContext('2d');
      ctx?.drawImage(image, 0, 0);
      
      // Simulación de análisis AI (reemplaza con tu servicio real)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockAnalysis: AIAnalysis = {
        description: "Portrait with good composition. Face centered with natural lighting.",
        suggestedWarps: [
          { area: "Face", action: "Slight stretch vertically for elongation" },
          { area: "Background", action: "Compress edges to draw focus to center" },
          { area: "Shoulders", action: "Widen slightly for better proportions" }
        ]
      };
      
      setAiAnalysis(mockAnalysis);
    } catch (err) {
      console.error('AI Analysis failed:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-gray-200 overflow-hidden select-none">
      {/* Sidebar */}
      <div className={`flex flex-col border-r border-white/10 bg-[#141414] transition-all duration-300 z-30 ${sidebarOpen ? 'w-80' : 'w-0 overflow-hidden'}`}>
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <Zap className="text-indigo-500" size={24} fill="currentColor" />
            WarpStudio <span className="text-xs bg-indigo-500 px-1.5 py-0.5 rounded text-white ml-1">PRO</span>
          </h1>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll p-4 space-y-6">
          <section className="space-y-3">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-widest px-1">Import</label>
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="file-upload" />
            <label htmlFor="file-upload" className="flex items-center gap-3 w-full p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl cursor-pointer transition-all">
              <Upload size={20} className="text-indigo-400" />
              <span className="text-sm font-medium">Upload Image</span>
            </label>
          </section>

          <section className="space-y-4">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-widest px-1">Deformation</label>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span>Mesh Density</span>
                <span className="bg-white/10 px-1.5 py-0.5 rounded font-mono">{gridSize}x{gridSize}</span>
              </div>
              <input 
                type="range" 
                min="4" 
                max="30" 
                value={gridSize} 
                onChange={(e) => setGridSize(parseInt(e.target.value))} 
                className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-indigo-500" 
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] text-gray-500 uppercase font-bold tracking-tighter">Symmetry</label>
              <div className="grid grid-cols-2 gap-1 bg-black/30 p-1 rounded-lg">
                {(['NONE', 'HORIZONTAL', 'VERTICAL', 'BOTH'] as SymmetryMode[]).map((m) => (
                  <button
                    key={m}
                    onClick={() => setSymmetry(m)}
                    className={`text-[9px] py-1.5 rounded transition-all font-bold ${symmetry === m ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-500 hover:bg-white/5'}`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-xl">
              <span className="text-sm font-medium flex items-center gap-2">
                <MousePointer2 size={18} className="text-gray-400" />
                Selection
              </span>
              <button 
                onClick={() => canvasRef.current?.clearSelection()} 
                className="px-3 py-1 bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 rounded-lg transition-colors text-xs font-bold"
              >
                Clear
              </button>
            </div>
          </section>

          <section className="space-y-3">
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-widest px-1">AI Assistant</label>
            <button 
              disabled={!image || isAnalyzing} 
              onClick={handleAiAnalyze} 
              className="flex items-center justify-center gap-3 w-full p-3 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 rounded-xl cursor-pointer transition-all disabled:opacity-50 group"
            >
              <Zap size={20} className={`text-indigo-400 ${isAnalyzing ? 'animate-pulse' : 'group-hover:scale-110'}`} />
              <span className="text-sm font-semibold text-indigo-300">
                {isAnalyzing ? 'Analyzing...' : 'Analyze Features'}
              </span>
            </button>
            {aiAnalysis && (
              <div className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2">
                <p className="text-xs text-gray-400 leading-relaxed italic">"{aiAnalysis.description}"</p>
                <div className="space-y-1 pt-2">
                  {aiAnalysis.suggestedWarps.map((s, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs bg-white/5 p-1.5 rounded">
                      <ChevronRight size={14} className="mt-0.5 text-indigo-400 shrink-0" />
                      <span><strong className="text-gray-200">{s.area}:</strong> {s.action}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>

        <div className="p-4 border-t border-white/10 bg-black/20 text-[10px] text-gray-500 flex flex-col gap-1">
          <div className="flex justify-between">
            <span>v3.0.0-pro</span>
            <span className="flex items-center gap-1">
              <Info size={10} /> Shift+Click: Multi-select
            </span>
          </div>
        </div>
      </div>

      {/* Main workspace */}
      <div className="flex-1 flex flex-col relative">
        <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 flex gap-2 p-1.5 bg-[#1a1a1a]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl">
          <ToolButton active={mode === 'WARP'} onClick={() => setMode('WARP')} icon={<Grid3X3 size={20} />} label="Warp" />
          <ToolButton active={mode === 'MOVE'} onClick={() => setMode('MOVE')} icon={<Move size={20} />} label="Pan" />
          <div className="w-px h-6 bg-white/10 mx-1 self-center" />
          <div className="flex gap-0.5">
            <ToolButton onClick={() => canvasRef.current?.undo()} icon={<Undo2 size={18} />} label="" />
            <div className="flex items-center px-2 text-[10px] font-bold text-indigo-400 uppercase tracking-tighter">Step</div>
            <ToolButton onClick={() => canvasRef.current?.redo()} icon={<Redo2 size={18} />} label="" />
          </div>
          <div className="w-px h-6 bg-white/10 mx-1 self-center" />
          <div className="flex gap-0.5">
            <ToolButton onClick={() => canvasRef.current?.zoomIn()} icon={<ZoomIn size={18} />} label="" />
            <ToolButton onClick={() => canvasRef.current?.zoomOut()} icon={<ZoomOut size={18} />} label="" />
            <ToolButton onClick={() => canvasRef.current?.resetZoom()} icon={<Maximize size={18} />} label="" />
          </div>
          <div className="w-px h-6 bg-white/10 mx-1 self-center" />
          <ToolButton onClick={() => canvasRef.current?.resetMesh()} icon={<RotateCcw size={20} />} label="Reset" />
          <ToolButton onClick={() => canvasRef.current?.exportImage()} icon={<Download size={20} />} label="Export" primary />
        </div>

        {!sidebarOpen && (
          <button 
            onClick={() => setSidebarOpen(true)} 
            className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-indigo-500 rounded-full z-20 shadow-lg hover:bg-indigo-600 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        )}
        
        {sidebarOpen && (
          <button 
            onClick={() => setSidebarOpen(false)} 
            className="absolute left-[310px] top-1/2 -translate-y-1/2 p-1.5 bg-white/10 hover:bg-white/20 rounded-full z-20 backdrop-blur transition-colors"
          >
            <ChevronRight size={16} className="rotate-180" />
          </button>
        )}

        <div className="flex-1 bg-[#0a0a0a] pattern-dots relative">
          {!image ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 text-center">
              <div className="w-24 h-24 rounded-3xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center shadow-inner">
                <Upload size={40} className="text-indigo-400 animate-bounce" />
              </div>
              <h2 className="text-2xl font-bold text-white">Upload to begin warping</h2>
            </div>
          ) : (
            <MeshCanvas 
              ref={canvasRef} 
              image={image} 
              gridSize={gridSize} 
              showMesh={showMesh} 
              mode={mode} 
              symmetry={symmetry} 
            />
          )}
        </div>
      </div>
      
      <style>{`
        .pattern-dots { 
          background-image: radial-gradient(#ffffff08 1px, transparent 1px); 
          background-size: 32px 32px; 
        }
        .custom-scroll::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scroll::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scroll::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 3px;
        }
        .custom-scroll::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
};

const ToolButton: React.FC<{ 
  active?: boolean; 
  onClick: () => void; 
  icon: React.ReactNode; 
  label: string; 
  primary?: boolean;
  disabled?: boolean;
}> = ({ active, onClick, icon, label, primary, disabled }) => (
  <button 
    onClick={onClick} 
    disabled={disabled}
    className={`group flex items-center gap-2 px-3 py-2 rounded-xl transition-all relative disabled:opacity-50 disabled:cursor-not-allowed ${
      active 
        ? 'bg-indigo-600 text-white shadow-lg' 
        : primary 
          ? 'bg-indigo-500/20 hover:bg-indigo-500 hover:text-white border border-indigo-500/40 text-indigo-300' 
          : 'text-gray-400 hover:text-white hover:bg-white/5'
    }`}
  >
    {icon}
    {label && <span className="text-sm font-semibold">{label}</span>}
  </button>
);

export default App;