
export interface Point {
  x: number;
  y: number;
}

export interface MeshNode extends Point {
  originalX: number;
  originalY: number;
  id: string;
}

export interface EditorState {
  image: HTMLImageElement | null;
  meshNodes: MeshNode[];
  gridSize: { rows: number; cols: number };
  isWarping: boolean;
  showMesh: boolean;
  history: MeshNode[][];
  historyIndex: number;
}

export type ToolMode = 'MOVE' | 'WARP' | 'PIN';
export type SymmetryMode = 'NONE' | 'HORIZONTAL' | 'VERTICAL' | 'BOTH';
